const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);
// Define the root route handler
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});
const usersMap = {};

io.on('connection', socket => {
  console.log('A user connected');

  socket.on('join', username => {
    socket.username = username;
    usersMap[username] = socket;
    const users = Object.keys(usersMap);
    io.emit('user joined', username, users);
  });

  socket.on('disconnect', () => {
    console.log('A user disconnected');
    const username = socket.username;
    delete usersMap[username];
    const users = Object.keys(usersMap);
    io.emit('user left', username, users);
  });

  socket.on('broadcast message', message => {
    io.emit('broadcast message', socket.username, message);
  });

  socket.on('private message', ({ recipient, message }) => {
    const sender = socket.username;
    const recipientSocket = usersMap[recipient];
    if (recipientSocket) {
      recipientSocket.emit('private message', sender, recipient, message);
      socket.emit('private message', sender, recipient, message); // Also send the message to the sender for confirmation
    } else {
      socket.emit('recipient not found', recipient);
    }
  });
});

const port = 8080;
server.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
